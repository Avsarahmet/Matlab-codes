u = randi([10 20],1,100);
v = rand(1,100)*10+10;
q1rmsd(u,v)
rms(u-v)